#!/bin/bash

AWS_REGION=$(python get_aws_creds.py region)
AWS_KEY=$(python get_aws_creds.py access)
AWS_SECRET_KEY=$(python get_aws_creds.py secret)

aws configure set aws_access_key_id $AWS_KEY \
&& aws configure set aws_secret_access_key $AWS_SECRET_KEY \
&& aws configure set default.region $AWS_REGION

chmod +x set_aws_creds.sh