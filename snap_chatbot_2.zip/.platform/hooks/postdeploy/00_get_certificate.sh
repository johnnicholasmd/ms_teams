#!/usr/bin/env bash

# https://medium.com/edataconsulting/how-to-get-a-ssl-certificate-running-in-aws-elastic-beanstalk-using-certbot-6daa9baa3997

# sudo certbot certonly --dry-run --test-cert --domain "${CERTDOMAIN}" --email "${CERT_EMAIL}" --nginx --non-interactive --agree-tos --verbose --rsa-key-size 4096

# TODO: ENABLE HTTPS

sudo certbot --domain "${CERTDOMAIN}" --email "${CERT_EMAIL}" --nginx --non-interactive --agree-tos --verbose --rsa-key-size 4096
