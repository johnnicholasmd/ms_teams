import os, psycopg2, base64, sys
from dotenv import load_dotenv

load_dotenv()

connection_uri = f"postgresql://{os.getenv('DB_USER')}:{os.getenv('DB_PASSWORD')}@{os.getenv('DB_HOST')}:{os.getenv('DB_PORT')}/{os.getenv('DB_NAME')}"
sql_query = "select * from s3_bucket.s3_conn;"

with psycopg2.connect(connection_uri) as conn:
                with conn.cursor() as cursor:
                    cursor.execute(sql_query)
                    columns = [desc[0] for desc in cursor.description]
                    res = [dict(zip(columns, row)) for row in cursor.fetchall()]
                    res = res[0]

def decode_credentials(encoded_credential):
    if encoded_credential.startswith("ENCODED:"):
        base64_encoded = encoded_credential.split(":", 1)[1]
        return base64.b64decode(base64_encoded).decode('utf-8')
    else:
        return None

region_name = res["region_name"]
encoded_secret_key = res["encoded_secret_key"]
encoded_access_key = res["encoded_access_key"]

decoded_secret_key = decode_credentials(encoded_secret_key)
decoded_access_key = decode_credentials(encoded_access_key)

if __name__ == "__main__":
    a = str(sys.argv[1])
    if a == "region":
          print(region_name)
    elif a == "access":
          print(decoded_access_key)
    elif a == "secret":
          print(decoded_secret_key)