from django.apps import AppConfig


class Gpt4AllAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'gpt4all_app'
